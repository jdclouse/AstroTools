gam1 = sym('gam1');
gam2 = sym('gam2');
gam3 = sym('gam3');
gamma_vec = [gam1; gam2; gam3]

gamma_skew = vecSkew(gamma_vec)
