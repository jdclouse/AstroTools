function printVector( vector, units )
fcnPrintQueue(mfilename('fullpath'))
fprintf('[%f; %f; %f] %s\n', vector(1), vector(2), vector(3), units);
end

